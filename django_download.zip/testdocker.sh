### echo "Hare Krishna"
### echo "gauranga"
### echo $1
### echo $2
### export $(dbus-launch) && export DISPLAY=:0.0 &&
### #terminator -T "youtube-dl" -p default -x zsh /home/simha/.public_html/ytdl1_dash_worst_wget_url.sh "$1" "$2"
### zsh /home/simha/.public_html/ytdl1_dash_worst_wget_url.sh "$1" "$2"
### echo "hari bol"



set -x -o verbose;

echo "###############################################################################################################"
youurl=$1;
echo $youurl
today=`date +%Y-%m-%d-%H_%M_%S_%N`
echo $today

#tmux new-session -d -s "$today" zsh /home/simha/.public_html/ytdl1_dash_worst_wget_url.sh $youurl $format
#tmux new-session -d -s "$today" zsh /home/simha/.public_html/shell101docker.sh $youurl
#export $(dbus-launch) && export DISPLAY=:0.0 && terminator -T "youtube-dl" -p default -x zsh /home/simha/.public_html/shell101docker.sh $youurl
tsp zsh /home/simha/.public_html/shell102.sh $youurl

echo "###############################################################################################################"
