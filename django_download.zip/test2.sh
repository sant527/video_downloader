set -x -o verbose;
ls -al
sleep 20000