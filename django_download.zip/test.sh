### echo "Hare Krishna"
### echo "gauranga"
### echo $1
### echo $2
### export $(dbus-launch) && export DISPLAY=:0.0 &&
### #terminator -T "youtube-dl" -p default -x zsh /home/simha/.public_html/ytdl1_dash_worst_wget_url.sh "$1" "$2"
### zsh /home/simha/.public_html/ytdl1_dash_worst_wget_url.sh "$1" "$2"
### echo "hari bol"


set -x -o verbose;

#echo "###############################################################################################################"
youurl=$1;
### #format="worst[height>=360]/worst/bestvideo[height>=360][ext=mp4]"
### format=$2;
### stype=$3
### if [ -z "${stype}" ]; then
###     echo "VAR is unset or set to the empty string"
###     stype="mp4"
### fi
### echo $format
#echo $youurl
### echo $type
today=`date +%Y-%m-%d-%H_%M_%S_%N`
#echo $today

#tmux new-session -d -s "$today" zsh /home/simha/.public_html/ytdl1_dash_worst_wget_url.sh $youurl $format
#tmux new-session -d -s "$today" zsh /home/simha/.public_html/shell101.sh $youurl $today

tsp zsh /home/simha/.public_html/shell101.sh $youurl

#echo "###############################################################################################################"
