console.log("krishna");

url="https://www.aznude.com/azncdn/naomiscott/anatomyofascandal/anatomyofascandal-01x01-scott-uhd-01_hd.html"

videos = $("a.video.animate-thumb.tt.show-clip")

videos.each(function(i, obj) {
    console.log(i)
    console.log(obj.href)
    url=obj.href
    $.get(url, function (data) {
        console.log($(data).filter("div.videoButtons"))
        console.log(data)
        let regexp = /<a href="\/\/(cdn[0-9].aznude.com\/.*mp4)/g;
        let matches = [...data.matchAll(regexp)];
        vid = matches[0][1].replace("hd.mp4", "hi.mp4");
        console.log(vid)
        var url1="http://127.0.0.1:8000/run-sh?url="+vid
        $.get(url1,function(data){console.log(data)})
    });
});

