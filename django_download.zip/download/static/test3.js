console.log("krishna");

$("#header").remove();
$("#container").each(function () {
    this.className = "viewport";
});

j = 0;
(function loadNext() {
    if (j < 100) {
        console.log(j);
        loadData().then(function () {
            console.log("inside");
            j = j + 1;
            loadNext();
        });
    }
})();

function loadData() {
    url = $(".viewport:last a.pagination_next:last")[0].href;
    console.log(url);
    $(".viewport:last").after('<div class="viewport"></div>');
    return $.get(url, function (data) {
        $(".viewport:last").html($(data).filter("div#container")[0].outerHTML);
    });
}

// https://xossipfap.net/forum/thread-43274-page-2.html

// url = $(".viewport:last a.similarr")[0].href;

// //alert(url);

// //"https://imagetwist.com/?op=rand_file&usr_id=302250"

// $.ajax({
//  type: "GET",
//  url: url,
//  statusCode: {
//      301: function (responseObject, textStatus, errorThrown) {
//          alert("301");
//      },
//      302: function (responseObject, textStatus, errorThrown) {
//          alert("302");
//      },
//  },
// })
//  .done(function (data) {
//      //window.location.href = url;

//      //alert("done");
//      $(".viewport").html($(data).find("div.container").html());
//  })
//  .fail(function (jqXHR, textStatus) {
//      alert("Something went wrong: " + textStatus);
//  })
//  .always(function (jqXHR, textStatus) {
//      console.log("TESTING");
//      //alert("Ajax request was finished");
//  });
