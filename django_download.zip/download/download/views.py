import json

import subprocess
import os
from django.http import HttpResponse

def index(request):
    try:
        if request.GET['format'] is None: # The variable
            print('It is None')
    except:
        print ("This variable is not defined")
        format_hare = 'worst[height>=360]/worst/bestvideo[height>=360][ext=mp4]'
        pass
    else:
        print ("It is defined and has a value")
        format_hare = request.GET['format']


    url_get= request.GET['url']
    print("url_get: "+url_get)
    print("format_hare: "+format_hare)
    #myCmd='sh /home/web_dev/django_download/test.sh'
    myCmd2='/home/web_dev/django_download/test.sh'
    #subprocess.call(['/usr/bin/zsh','/home/web_dev/django_download/test.sh', url_get, format_hare])
    subprocess.Popen(['/usr/bin/zsh','/home/web_dev/django_download/test.sh', url_get, format_hare])
    #os.system(myCmd)

    #os.system('ls -al')
    html = "<html><body>"+url_get+"</body></html>"
    return HttpResponse(html)

def index2(request):


    url_get= request.GET['url']
    subprocess.Popen(['/usr/bin/zsh','/home/web_dev/django_download/testdocker.sh', url_get])
    html = "<html><body>"+url_get+"</body></html>"
    return HttpResponse(html)



def img_dowload(request):


    url_get= request.GET['url']
    subprocess.Popen(['/usr/bin/zsh','/home/web_dev/django_download/testimg.sh', url_get])
    html = "<html><body>"+url_get+"</body></html>"
    return HttpResponse(html)

#type=5555555you1&format=&url=http://www.flickr.com/photos/146315739@N02/30506625770/in/photostream/

from django.views.decorators.csrf import csrf_exempt

from .pretty_printing import dumps

@csrf_exempt
def test(request):
    print(dumps(request))
    if request.method == 'POST':

        print(dumps(request.POST.getlist('target_list')))

        print(dumps(request.POST.getlist('notification[email_list]')))

        print(dumps(request.POST.getlist('notification[gaura]')))

        print(dict(request.POST.items()))

        try:
            my_uploaded_file = request.FILES['target_file'].read()
        except:
            print("NO file uploaded")

        data = {
            "status": True,
            "message":
            {
                "submittal_ts": "2021-12-01 19:25:38",
                "batch_id": "202112-0119-2538-2f3c3639-8746-4bdd-9e17-aab5c2a79396",
                "schedule_type": "scheduled",
                "targets":
                {
                    "total_tgt_Count": 25,
                    "valid_tgt": 15,
                    "invalid_tgt": 10,
                    "submitted": 15,
                    "not_submitted": 15,
                    "not_submitted_list":
                    [
                        "ECA9.40F1.9C91:77",
                        "ECA940F19C911234",
                        "ECA9.40F1.9C91:77",
                        "ECA940F19C911234",
                        "ECA9.40F1.9C91:77",
                        "ECA940F19C911234",
                        "ECA9.40F1.9C91:77",
                        "ECA940F19C911234",
                        "ECA9.40F1.9C91:77",
                        "ECA940F19C911234",
                        "hare Krishna"
                    ]
                },
                "notifications":
                {
                    "state": "Not configured",
                    "total_emails": 0,
                    "comments": "Notification State Disabled"
                }
            }
        }

        return HttpResponse(json.dumps(data,default=str),status=201,content_type="application/json")
    else:
        return HttpResponse(json.dumps({"status":"Only post allowed"},default=str),status=201,content_type="application/json")


