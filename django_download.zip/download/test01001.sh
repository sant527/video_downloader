while true;
do;
        echo "##########################################"  
       ??? For list of tmux session; do
        sleep 1;
        ??? session name
        ??? recent last 5 lines of output
        done
        echo "##########################################"
done;


tmux capture-pane -p -S- -E- -e -t *2020-04-10-11_52_01_953906687* |sed '/^$/d'|tail -5